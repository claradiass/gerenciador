package br.edu.ifpb.padroes.biblioteca.gerenciador;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GerenciadorApplicationTests {

	@Test
	void contextLoads() {
	}

}
